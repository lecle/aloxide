from iconservice import *

TAG = 'hello'


class hello(IconScoreBase):

    def __init__(self, db: IconScoreDatabase) -> None:
        super().__init__(db)
        self._poll_table = DictDB('polltbl', db, value_type=str)
        self._vote_table = DictDB('votetbl', db, value_type=str)
    def on_install(self) -> None:
        super().on_install()

    def on_update(self) -> None:
        super().on_update()

    @external(readonly=True)
    def hi(self) -> str:
        Logger.debug(f'Hello, world!' + str(self.msg.sender), TAG)
        return "Hi"

    @external
    def getpoll(self, id: int) -> str:
        return self._poll_table[id]
    @external
    def getvote(self, id: int) -> str:
        return self._vote_table[id]

    @external
    def crepoll(self, id: int, name: str, body: str):
        inputData = {}
        inputData["id"] = str(id)
        inputData["name"] = str(name)
        inputData["body"] = str(body)
        if self._poll_table[id] != "":
            revert('id already exists')

        self._poll_table[id] = json_dumps(inputData)
    @external
    def crevote(self, id: int, pollId: int, ownerId: int, point: int):
        inputData = {}
        inputData["id"] = str(id)
        inputData["pollId"] = str(pollId)
        inputData["ownerId"] = str(ownerId)
        inputData["point"] = str(point)
        if self._vote_table[id] != "":
            revert('id already exists')

        self._vote_table[id] = json_dumps(inputData)

    @external
    def updpoll(self, id: int, name: str, body: str):
        inputData = {}
        inputData["id"] = str(id)
        inputData["name"] = str(name)
        inputData["body"] = str(body)
        if self._poll_table[id] == "":
            revert('id does not exists')

        self._poll_table[id] = json_dumps(inputData)
    @external
    def updvote(self, id: int, pollId: int, ownerId: int, point: int):
        inputData = {}
        inputData["id"] = str(id)
        inputData["pollId"] = str(pollId)
        inputData["ownerId"] = str(ownerId)
        inputData["point"] = str(point)
        if self._vote_table[id] == "":
            revert('id does not exists')

        self._vote_table[id] = json_dumps(inputData)

    @external
    def delpoll(self, id: int):
        if self._poll_table[id] == "":
            revert('id does not exists')

        self._poll_table.remove(id)
    @external
    def delvote(self, id: int):
        if self._vote_table[id] == "":
            revert('id does not exists')

        self._vote_table.remove(id)
